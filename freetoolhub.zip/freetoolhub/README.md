# FreeToolHub 🛠️

Free online tools site built with Next.js 14

## Setup

```bash
npm install
npm run dev
```

## Deploy to Vercel (Free)

1. Push to GitHub
2. Go to vercel.com
3. Import repository
4. Deploy — done!

## Add Your AdSense Code

In `src/app/layout.tsx`, replace:
```
ca-pub-XXXXXXXXXXXXXXXX
```
With your real AdSense publisher ID.

In `src/components/Layout.tsx`, replace AdSense slot comments with real ad units.

## Add Google Analytics

In `src/app/layout.tsx`, add your GA4 script tag.

## Domain Setup (freetoolhub.com)

1. Buy domain at porkbun.com (~$9/year)
2. In Vercel: Settings → Domains → Add domain
3. Update nameservers at porkbun to point to Vercel

## Stack
- Next.js 14 (App Router)
- TypeScript
- Tailwind CSS
- 80+ free tools
- AdSense ready
- SEO optimized (sitemap, robots, schema)
- Privacy Policy, About, Contact pages

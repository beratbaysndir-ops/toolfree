'use client'
import Link from 'next/link'
import { useState } from 'react'
import { CATEGORIES } from '@/lib/tools'

export default function Layout({ children }: { children: React.ReactNode }) {
  const [menuOpen, setMenuOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')

  return (
    <div className="min-h-screen flex flex-col" style={{ background: '#0a0f0a' }}>
      {/* Top AdSense Banner */}
      <div className="w-full px-4 py-2 flex justify-center" style={{ background: '#0d140d' }}>
        <div className="adsense-slot w-full max-w-4xl text-xs">
          {/* AdSense: ca-pub-XXXXXXXX slot top-banner */}
        </div>
      </div>

      {/* Header */}
      <header style={{ background: '#0d140d', borderBottom: '1px solid #1a2e1a' }}>
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between gap-4">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 shrink-0">
            <div style={{ background: '#22c55e', borderRadius: '10px', width: 36, height: 36, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>🛠️</div>
            <span style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 20, color: '#e2f0e2' }}>
              Free<span style={{ color: '#22c55e' }}>Tool</span>Hub
            </span>
          </Link>

          {/* Search */}
          <div className="flex-1 max-w-md hidden md:block">
            <input
              className="tool-input text-sm"
              placeholder="Search 80+ tools..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter' && searchQuery) {
                  window.location.href = `/?search=${encodeURIComponent(searchQuery)}`
                }
              }}
            />
          </div>

          {/* Nav */}
          <nav className="hidden md:flex items-center gap-6 text-sm" style={{ color: '#6b8f6b' }}>
            <Link href="/tools" className="hover:text-green-400 transition-colors">All Tools</Link>
            <Link href="/blog" className="hover:text-green-400 transition-colors">Blog</Link>
            <Link href="/about" className="hover:text-green-400 transition-colors">About</Link>
          </nav>

          {/* Mobile menu */}
          <button onClick={() => setMenuOpen(!menuOpen)} className="md:hidden text-2xl" style={{ color: '#e2f0e2', background: 'none', border: 'none', cursor: 'pointer' }}>
            {menuOpen ? '✕' : '☰'}
          </button>
        </div>

        {/* Mobile menu dropdown */}
        {menuOpen && (
          <div style={{ background: '#111a11', borderTop: '1px solid #1a2e1a' }} className="md:hidden px-4 py-4 flex flex-col gap-3">
            <input className="tool-input text-sm" placeholder="Search tools..." />
            <Link href="/tools" className="text-sm" style={{ color: '#6b8f6b' }}>All Tools</Link>
            <Link href="/blog" className="text-sm" style={{ color: '#6b8f6b' }}>Blog</Link>
            <Link href="/about" className="text-sm" style={{ color: '#6b8f6b' }}>About</Link>
          </div>
        )}
      </header>

      {/* Main */}
      <main className="flex-1">{children}</main>

      {/* Footer */}
      <footer style={{ background: '#0d140d', borderTop: '1px solid #1a2e1a', marginTop: 80 }}>
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-10">
            {/* Brand */}
            <div className="col-span-2 md:col-span-1">
              <div className="flex items-center gap-2 mb-3">
                <div style={{ background: '#22c55e', borderRadius: '8px', width: 28, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14 }}>🛠️</div>
                <span style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, color: '#e2f0e2' }}>FreeToolHub</span>
              </div>
              <p className="text-sm" style={{ color: '#6b8f6b', lineHeight: 1.6 }}>
                Free online tools for images, text, developers, SEO and more. No signup required.
              </p>
            </div>

            {/* Tools */}
            <div>
              <p className="text-sm font-semibold mb-3" style={{ color: '#e2f0e2', fontFamily: 'Syne, sans-serif' }}>Popular Tools</p>
              {['image-compressor', 'json-formatter', 'password-generator', 'word-counter', 'base64-encode'].map(id => (
                <Link key={id} href={`/tools/${id}`} className="block text-sm mb-2 hover:text-green-400 transition-colors capitalize" style={{ color: '#6b8f6b' }}>
                  {id.replace(/-/g, ' ')}
                </Link>
              ))}
            </div>

            {/* Categories */}
            <div>
              <p className="text-sm font-semibold mb-3" style={{ color: '#e2f0e2', fontFamily: 'Syne, sans-serif' }}>Categories</p>
              {CATEGORIES.slice(0, 5).map(c => (
                <Link key={c.id} href={`/tools?category=${c.id}`} className="block text-sm mb-2 hover:text-green-400 transition-colors" style={{ color: '#6b8f6b' }}>
                  {c.icon} {c.name}
                </Link>
              ))}
            </div>

            {/* Pages */}
            <div>
              <p className="text-sm font-semibold mb-3" style={{ color: '#e2f0e2', fontFamily: 'Syne, sans-serif' }}>Company</p>
              {[['/', 'Home'], ['/about', 'About'], ['/blog', 'Blog'], ['/contact', 'Contact'], ['/privacy-policy', 'Privacy Policy']].map(([href, label]) => (
                <Link key={href} href={href} className="block text-sm mb-2 hover:text-green-400 transition-colors" style={{ color: '#6b8f6b' }}>
                  {label}
                </Link>
              ))}
            </div>
          </div>

          <div style={{ borderTop: '1px solid #1a2e1a', paddingTop: 24, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
            <p className="text-xs" style={{ color: '#6b8f6b' }}>© 2026 FreeToolHub. All rights reserved.</p>
            <p className="text-xs" style={{ color: '#6b8f6b' }}>Free online tools — no signup, no limits</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

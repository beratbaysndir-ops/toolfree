export const CATEGORIES = [
  {
    id: 'image',
    name: 'Image Tools',
    icon: '🖼️',
    color: '#22c55e',
    description: 'Compress, convert, resize and edit images online for free',
    tools: [
      { id: 'image-compressor', name: 'Image Compressor', desc: 'Reduce image file size without losing quality', keywords: 'compress image online free' },
      { id: 'image-converter', name: 'Image Converter', desc: 'Convert images between all popular formats', keywords: 'image format converter' },
      { id: 'jpg-to-png', name: 'JPG to PNG', desc: 'Convert JPG images to PNG format instantly', keywords: 'jpg to png converter free' },
      { id: 'png-to-jpg', name: 'PNG to JPG', desc: 'Convert PNG images to JPG format online', keywords: 'png to jpg converter' },
      { id: 'png-to-webp', name: 'PNG to WebP', desc: 'Convert PNG to WebP for faster web loading', keywords: 'png to webp converter' },
      { id: 'webp-to-png', name: 'WebP to PNG', desc: 'Convert WebP images to PNG format', keywords: 'webp to png free' },
      { id: 'resize-image', name: 'Resize Image', desc: 'Resize images to any dimension online', keywords: 'resize image online' },
      { id: 'crop-image', name: 'Crop Image', desc: 'Crop images to custom dimensions free', keywords: 'crop image online' },
      { id: 'rotate-image', name: 'Rotate Image', desc: 'Rotate images 90, 180 or any angle', keywords: 'rotate image online' },
      { id: 'flip-image', name: 'Flip Image', desc: 'Flip images horizontally or vertically', keywords: 'flip image online free' },
      { id: 'image-to-text', name: 'Image to Text (OCR)', desc: 'Extract text from images using OCR', keywords: 'image to text ocr online' },
      { id: 'image-watermark', name: 'Image Watermark', desc: 'Add watermark text or logo to images', keywords: 'add watermark to image' },
      { id: 'blur-image', name: 'Blur Image', desc: 'Add blur effect to images online', keywords: 'blur image online' },
      { id: 'image-color-picker', name: 'Color Picker', desc: 'Pick colors from any image instantly', keywords: 'image color picker online' },
      { id: 'image-to-base64', name: 'Image to Base64', desc: 'Convert images to Base64 string', keywords: 'image to base64 encoder' },
    ]
  },
  {
    id: 'video',
    name: 'Video Tools',
    icon: '🎬',
    color: '#f59e0b',
    description: 'Convert, compress and edit videos online free',
    tools: [
      { id: 'mp4-to-mp3', name: 'MP4 to MP3', desc: 'Extract audio from video files free', keywords: 'mp4 to mp3 converter online' },
      { id: 'video-to-gif', name: 'Video to GIF', desc: 'Convert video clips to animated GIF', keywords: 'video to gif converter' },
      { id: 'trim-video', name: 'Trim Video', desc: 'Cut and trim videos online for free', keywords: 'trim video online free' },
      { id: 'video-speed', name: 'Video Speed Changer', desc: 'Speed up or slow down videos', keywords: 'change video speed online' },
    ]
  },
  {
    id: 'social',
    name: 'Social Media Tools',
    icon: '📱',
    color: '#e879f9',
    description: 'Download videos and photos from social media',
    tools: [
      { id: 'youtube-thumbnail', name: 'YouTube Thumbnail Downloader', desc: 'Download YouTube video thumbnails free', keywords: 'youtube thumbnail downloader' },
      { id: 'youtube-tags', name: 'YouTube Tags Extractor', desc: 'Extract tags from any YouTube video', keywords: 'youtube tags extractor' },
      { id: 'youtube-title', name: 'YouTube Title Generator', desc: 'Generate SEO-optimized YouTube titles', keywords: 'youtube title generator' },
      { id: 'youtube-description', name: 'YouTube Description Generator', desc: 'Create YouTube descriptions with AI', keywords: 'youtube description generator' },
    ]
  },
  {
    id: 'text',
    name: 'Text Tools',
    icon: '✍️',
    color: '#60a5fa',
    description: 'Word counter, case converter and text utilities',
    tools: [
      { id: 'word-counter', name: 'Word Counter', desc: 'Count words, characters and sentences', keywords: 'word counter online free' },
      { id: 'character-counter', name: 'Character Counter', desc: 'Count characters with and without spaces', keywords: 'character counter online' },
      { id: 'case-converter', name: 'Case Converter', desc: 'Convert text to upper, lower, title case', keywords: 'text case converter online' },
      { id: 'remove-duplicate-lines', name: 'Remove Duplicate Lines', desc: 'Remove duplicate lines from text', keywords: 'remove duplicate lines online' },
      { id: 'text-diff', name: 'Text Diff Checker', desc: 'Compare two texts and find differences', keywords: 'text diff checker online' },
      { id: 'lorem-ipsum', name: 'Lorem Ipsum Generator', desc: 'Generate Lorem Ipsum placeholder text', keywords: 'lorem ipsum generator' },
      { id: 'remove-line-breaks', name: 'Remove Line Breaks', desc: 'Remove line breaks from text easily', keywords: 'remove line breaks online' },
      { id: 'text-sorter', name: 'Text Sorter', desc: 'Sort lines alphabetically or by length', keywords: 'text sorter online' },
      { id: 'reverse-text', name: 'Reverse Text', desc: 'Reverse text string or words online', keywords: 'reverse text generator' },
      { id: 'text-to-slug', name: 'Text to Slug', desc: 'Convert text to URL-friendly slug', keywords: 'text to slug converter' },
    ]
  },
  {
    id: 'developer',
    name: 'Developer Tools',
    icon: '👨‍💻',
    color: '#34d399',
    description: 'JSON formatter, Base64, UUID and developer utilities',
    tools: [
      { id: 'json-formatter', name: 'JSON Formatter', desc: 'Format and beautify JSON data online', keywords: 'json formatter online' },
      { id: 'json-validator', name: 'JSON Validator', desc: 'Validate JSON syntax and structure', keywords: 'json validator online' },
      { id: 'base64-encode', name: 'Base64 Encode', desc: 'Encode text to Base64 format', keywords: 'base64 encoder online' },
      { id: 'base64-decode', name: 'Base64 Decode', desc: 'Decode Base64 to plain text', keywords: 'base64 decoder online' },
      { id: 'uuid-generator', name: 'UUID Generator', desc: 'Generate random UUID/GUID strings', keywords: 'uuid generator online' },
      { id: 'password-generator', name: 'Password Generator', desc: 'Generate strong secure passwords', keywords: 'password generator online' },
      { id: 'hash-generator', name: 'Hash Generator', desc: 'Generate MD5, SHA256 hash values', keywords: 'md5 sha256 hash generator' },
      { id: 'url-encoder', name: 'URL Encoder', desc: 'Encode URLs for safe transmission', keywords: 'url encoder online' },
      { id: 'url-decoder', name: 'URL Decoder', desc: 'Decode encoded URLs instantly', keywords: 'url decoder online' },
      { id: 'html-encoder', name: 'HTML Encoder', desc: 'Encode special HTML characters', keywords: 'html encoder online' },
      { id: 'html-decoder', name: 'HTML Decoder', desc: 'Decode HTML entities to text', keywords: 'html decoder online' },
      { id: 'jwt-decoder', name: 'JWT Decoder', desc: 'Decode and inspect JWT tokens', keywords: 'jwt decoder online' },
      { id: 'regex-tester', name: 'Regex Tester', desc: 'Test regular expressions online', keywords: 'regex tester online' },
    ]
  },
  {
    id: 'seo',
    name: 'SEO Tools',
    icon: '🔎',
    color: '#fb923c',
    description: 'Meta tag analyzer, sitemap generator and SEO utilities',
    tools: [
      { id: 'keyword-density', name: 'Keyword Density Checker', desc: 'Analyze keyword density in content', keywords: 'keyword density checker free' },
      { id: 'meta-tag-analyzer', name: 'Meta Tag Analyzer', desc: 'Analyze meta tags of any website', keywords: 'meta tag analyzer' },
      { id: 'robots-txt-generator', name: 'Robots.txt Generator', desc: 'Generate robots.txt file for your site', keywords: 'robots txt generator online' },
      { id: 'open-graph-generator', name: 'Open Graph Generator', desc: 'Generate Open Graph meta tags', keywords: 'open graph generator' },
      { id: 'domain-age-checker', name: 'Domain Age Checker', desc: 'Check the age of any domain', keywords: 'domain age checker' },
      { id: 'http-header-checker', name: 'HTTP Header Checker', desc: 'Check HTTP headers of any URL', keywords: 'http header checker' },
      { id: 'redirect-checker', name: 'Redirect Checker', desc: 'Trace URL redirects and chains', keywords: 'redirect checker online' },
    ]
  },
  {
    id: 'security',
    name: 'Security Tools',
    icon: '🔐',
    color: '#f87171',
    description: 'Password checker, SSL checker and security utilities',
    tools: [
      { id: 'password-strength', name: 'Password Strength Checker', desc: 'Check how strong your password is', keywords: 'password strength checker' },
      { id: 'ssl-checker', name: 'SSL Checker', desc: 'Verify SSL certificate status of domains', keywords: 'ssl checker online' },
      { id: 'ip-lookup', name: 'IP Lookup', desc: 'Look up information about any IP address', keywords: 'ip lookup online' },
      { id: 'whois-lookup', name: 'Whois Lookup', desc: 'Get domain registration information', keywords: 'whois lookup free' },
      { id: 'dns-lookup', name: 'DNS Lookup', desc: 'Query DNS records for any domain', keywords: 'dns lookup online' },
    ]
  },
  {
    id: 'converter',
    name: 'Data & Converter',
    icon: '📊',
    color: '#a78bfa',
    description: 'Unit converter, currency and data conversion tools',
    tools: [
      { id: 'unit-converter', name: 'Unit Converter', desc: 'Convert between length, weight, temperature', keywords: 'unit converter online' },
      { id: 'binary-converter', name: 'Binary Converter', desc: 'Convert binary, decimal, hex, octal', keywords: 'binary to decimal converter' },
      { id: 'roman-numeral', name: 'Roman Numeral Converter', desc: 'Convert numbers to Roman numerals', keywords: 'roman numeral converter' },
      { id: 'number-to-words', name: 'Number to Words', desc: 'Convert numbers to English words', keywords: 'number to words converter' },
      { id: 'timezone-converter', name: 'Time Zone Converter', desc: 'Convert time between time zones', keywords: 'time zone converter' },
      { id: 'percentage-calculator', name: 'Percentage Calculator', desc: 'Calculate percentages easily', keywords: 'percentage calculator online' },
    ]
  },
  {
    id: 'pdf',
    name: 'PDF Tools',
    icon: '📄',
    color: '#f472b6',
    description: 'Merge, compress, split and convert PDF files free',
    tools: [
      { id: 'merge-pdf', name: 'Merge PDF', desc: 'Combine multiple PDF files into one', keywords: 'merge pdf online free' },
      { id: 'split-pdf', name: 'Split PDF', desc: 'Split PDF into separate pages', keywords: 'split pdf online' },
      { id: 'pdf-to-jpg', name: 'PDF to JPG', desc: 'Convert PDF pages to JPG images', keywords: 'pdf to jpg converter' },
      { id: 'jpg-to-pdf', name: 'JPG to PDF', desc: 'Convert JPG images to PDF', keywords: 'jpg to pdf converter free' },
      { id: 'rotate-pdf', name: 'Rotate PDF', desc: 'Rotate PDF pages to any angle', keywords: 'rotate pdf online' },
    ]
  },
  {
    id: 'calculator',
    name: 'Calculator Tools',
    icon: '🔢',
    color: '#2dd4bf',
    description: 'Age calculator, BMI, loan and financial calculators',
    tools: [
      { id: 'age-calculator', name: 'Age Calculator', desc: 'Calculate exact age from date of birth', keywords: 'age calculator online' },
      { id: 'bmi-calculator', name: 'BMI Calculator', desc: 'Calculate Body Mass Index free', keywords: 'bmi calculator online' },
      { id: 'loan-calculator', name: 'Loan Calculator', desc: 'Calculate monthly loan payments', keywords: 'loan calculator online' },
      { id: 'discount-calculator', name: 'Discount Calculator', desc: 'Calculate discounts and savings', keywords: 'discount calculator online' },
      { id: 'profit-margin', name: 'Profit Margin Calculator', desc: 'Calculate profit margins and markup', keywords: 'profit margin calculator' },
      { id: 'mortgage-calculator', name: 'Mortgage Calculator', desc: 'Calculate mortgage payments online', keywords: 'mortgage calculator free' },
    ]
  }
]

export const getAllTools = () => CATEGORIES.flatMap(c => c.tools.map(t => ({ ...t, category: c.id, categoryName: c.name, categoryIcon: c.icon })))

export const getToolById = (id: string) => {
  for (const cat of CATEGORIES) {
    const tool = cat.tools.find(t => t.id === id)
    if (tool) return { ...tool, category: cat.id, categoryName: cat.name, categoryIcon: cat.icon, categoryColor: cat.color }
  }
  return null
}

export const getCategoryById = (id: string) => CATEGORIES.find(c => c.id === id)

import Link from 'next/link'

export const metadata = {
  title: 'Blog — FreeToolHub | Tips, Guides & Tool Tutorials',
  description: 'Learn how to use free online tools. Guides, tips and tutorials for image compression, JSON formatting, SEO tools and more.',
}

const POSTS = [
  { slug: 'how-to-compress-images-online', title: 'How to Compress Images Online Without Losing Quality', date: 'March 10, 2026', category: 'Image Tools', readTime: '4 min', excerpt: 'Learn how to reduce image file sizes for faster website loading while maintaining visual quality.' },
  { slug: 'json-formatter-guide', title: 'JSON Formatter: How to Format and Validate JSON Online', date: 'March 8, 2026', category: 'Developer Tools', readTime: '3 min', excerpt: 'A complete guide to formatting, validating and beautifying JSON data using free online tools.' },
  { slug: 'strong-password-guide', title: 'How to Create Strong Passwords: Complete Security Guide', date: 'March 6, 2026', category: 'Security', readTime: '5 min', excerpt: 'Learn what makes a password secure and how to generate uncrackable passwords for free.' },
  { slug: 'image-format-guide', title: 'JPG vs PNG vs WebP: Which Image Format Should You Use?', date: 'March 4, 2026', category: 'Image Tools', readTime: '6 min', excerpt: 'A complete comparison of image formats to help you choose the right one for your use case.' },
  { slug: 'seo-meta-tags-guide', title: 'How to Write Perfect SEO Meta Tags in 2026', date: 'March 2, 2026', category: 'SEO', readTime: '7 min', excerpt: 'Master meta titles and descriptions to improve your search engine rankings.' },
  { slug: 'base64-encoding-explained', title: 'Base64 Encoding Explained: What It Is and How to Use It', date: 'February 28, 2026', category: 'Developer Tools', readTime: '4 min', excerpt: 'Understand Base64 encoding and decoding with practical examples and free online tools.' },
]

const CATEGORY_COLORS: { [key: string]: string } = {
  'Image Tools': '#22c55e',
  'Developer Tools': '#34d399',
  'Security': '#f87171',
  'SEO': '#fb923c',
  'PDF Tools': '#f472b6',
  'Text Tools': '#60a5fa',
}

export default function BlogPage() {
  return (
    <div style={{ maxWidth: 900, margin: '0 auto', padding: '60px 16px' }}>
      <h1 style={{ fontFamily: 'Syne, sans-serif', fontSize: 36, fontWeight: 800, marginBottom: 8 }}>Blog</h1>
      <p style={{ color: '#6b8f6b', marginBottom: 48, fontSize: 16 }}>Tips, guides and tutorials for free online tools</p>

      <div style={{ display: 'grid', gap: 20 }}>
        {POSTS.map(post => (
          <Link key={post.slug} href={`/blog/${post.slug}`}>
            <div className="tool-card" style={{ background: '#111a11', borderRadius: 16, padding: 28, cursor: 'pointer' }}>
              <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 12, flexWrap: 'wrap' }}>
                <span style={{ background: `${CATEGORY_COLORS[post.category] || '#22c55e'}20`, color: CATEGORY_COLORS[post.category] || '#22c55e', padding: '3px 10px', borderRadius: 20, fontSize: 12, fontWeight: 600 }}>{post.category}</span>
                <span style={{ color: '#6b8f6b', fontSize: 12 }}>{post.date}</span>
                <span style={{ color: '#6b8f6b', fontSize: 12 }}>⏱️ {post.readTime} read</span>
              </div>
              <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 20, fontWeight: 700, color: '#e2f0e2', marginBottom: 10, lineHeight: 1.3 }}>{post.title}</h2>
              <p style={{ color: '#6b8f6b', fontSize: 14, lineHeight: 1.6, margin: 0 }}>{post.excerpt}</p>
              <div style={{ marginTop: 16, color: '#22c55e', fontSize: 13, fontWeight: 600 }}>Read more →</div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}

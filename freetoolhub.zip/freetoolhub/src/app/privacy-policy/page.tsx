export const metadata = { title: 'Privacy Policy — FreeToolHub', description: 'FreeToolHub privacy policy. We respect your privacy.' }
export default function PrivacyPage() {
  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '60px 16px' }}>
      <h1 style={{ fontFamily: 'Syne, sans-serif', fontSize: 36, fontWeight: 800, marginBottom: 8 }}>Privacy Policy</h1>
      <p style={{ color: '#6b8f6b', marginBottom: 40 }}>Last updated: March 12, 2026</p>
      <div style={{ color: '#6b8f6b', lineHeight: 1.9, fontSize: 15 }}>
        {[
          ['Information We Collect', 'FreeToolHub does not require registration or account creation. Most tools process data entirely in your browser (client-side), meaning your files and data are never uploaded to our servers. We may collect anonymous usage analytics such as page views and tool usage counts.'],
          ['How We Use Your Information', 'Any anonymous data we collect is used solely to improve our tools and user experience. We do not sell, trade, or share your personal information with third parties.'],
          ['Cookies', 'We use cookies for analytics purposes (Google Analytics) and to serve relevant advertisements (Google AdSense). You can disable cookies in your browser settings.'],
          ['Google AdSense', 'We use Google AdSense to display advertisements. Google may use cookies to show relevant ads based on your browsing history. You can opt out at google.com/settings/ads.'],
          ['Third-Party Tools', 'Some tools may require processing on our servers (such as PDF tools). In these cases, uploaded files are processed immediately and deleted within 1 hour.'],
          ['Data Security', 'We implement appropriate security measures to protect against unauthorized access, alteration, or disclosure of your data.'],
          ['Children\'s Privacy', 'FreeToolHub is not directed at children under 13. We do not knowingly collect information from children.'],
          ['Changes to This Policy', 'We may update this privacy policy from time to time. Changes will be posted on this page.'],
          ['Contact', 'If you have questions about this privacy policy, please contact us through our Contact page.'],
        ].map(([title, content]) => (
          <div key={title as string} style={{ marginBottom: 32 }}>
            <h2 style={{ fontFamily: 'Syne, sans-serif', color: '#e2f0e2', fontSize: 18, marginBottom: 12 }}>{title as string}</h2>
            <p style={{ margin: 0 }}>{content as string}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

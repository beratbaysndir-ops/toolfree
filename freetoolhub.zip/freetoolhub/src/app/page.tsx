import Link from 'next/link'
import { CATEGORIES, getAllTools } from '@/lib/tools'

export default function HomePage() {
  const allTools = getAllTools()

  return (
    <div>
      {/* Hero */}
      <section style={{ padding: '80px 16px 60px', textAlign: 'center', background: 'linear-gradient(180deg, #0d140d 0%, #0a0f0a 100%)' }}>
        <div style={{ maxWidth: 700, margin: '0 auto' }}>
          <div className="tag" style={{ marginBottom: 20, display: 'inline-flex' }}>
            ✨ 80+ Free Tools — No Signup Required
          </div>
          <h1 style={{ fontFamily: 'Syne, sans-serif', fontSize: 'clamp(36px, 6vw, 64px)', fontWeight: 800, lineHeight: 1.1, marginBottom: 20 }}>
            All the tools you need,{' '}
            <span className="gradient-text">completely free</span>
          </h1>
          <p style={{ color: '#6b8f6b', fontSize: 18, lineHeight: 1.7, marginBottom: 40 }}>
            Image tools, developer utilities, text processors, PDF tools, SEO analyzers and more.
            Free forever, no account needed.
          </p>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link href="/tools">
              <button className="btn-primary" style={{ fontSize: 16, padding: '14px 28px' }}>
                Browse All Tools →
              </button>
            </Link>
            <Link href="#categories">
              <button className="btn-secondary" style={{ fontSize: 16, padding: '14px 28px' }}>
                View Categories
              </button>
            </Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section style={{ padding: '0 16px 60px' }}>
        <div style={{ maxWidth: 900, margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 16 }}>
          {[['80+', 'Free Tools'], ['0', 'Signup Required'], ['100%', 'Free Forever'], ['⚡', 'Instant Results']].map(([num, label]) => (
            <div key={label} style={{ background: '#111a11', border: '1px solid #1a2e1a', borderRadius: 12, padding: '20px 16px', textAlign: 'center' }}>
              <div style={{ fontFamily: 'Syne, sans-serif', fontSize: 28, fontWeight: 800, color: '#22c55e' }}>{num}</div>
              <div style={{ color: '#6b8f6b', fontSize: 13, marginTop: 4 }}>{label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* AdSense */}
      <div style={{ maxWidth: 900, margin: '0 auto 40px', padding: '0 16px' }}>
        <div className="adsense-slot">Ad Space</div>
      </div>

      {/* Categories */}
      <section id="categories" style={{ padding: '0 16px 80px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 28, fontWeight: 700, marginBottom: 8 }}>Browse by Category</h2>
          <p style={{ color: '#6b8f6b', marginBottom: 40 }}>Pick a category to explore all available tools</p>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 16 }}>
            {CATEGORIES.map(cat => (
              <Link key={cat.id} href={`/tools?category=${cat.id}`}>
                <div className="tool-card" style={{ background: '#111a11', borderRadius: 16, padding: 24, cursor: 'pointer' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
                    <span style={{ fontSize: 28 }}>{cat.icon}</span>
                    <div>
                      <h3 style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16, color: '#e2f0e2', margin: 0 }}>{cat.name}</h3>
                      <span style={{ fontSize: 12, color: '#6b8f6b' }}>{cat.tools.length} tools</span>
                    </div>
                  </div>
                  <p style={{ color: '#6b8f6b', fontSize: 13, lineHeight: 1.5, margin: 0 }}>{cat.description}</p>
                  <div style={{ marginTop: 16, display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                    {cat.tools.slice(0, 3).map(t => (
                      <span key={t.id} style={{ background: '#0a0f0a', color: '#6b8f6b', padding: '3px 8px', borderRadius: 6, fontSize: 11, border: '1px solid #1a2e1a' }}>{t.name}</span>
                    ))}
                    {cat.tools.length > 3 && <span style={{ color: '#22c55e', fontSize: 11 }}>+{cat.tools.length - 3} more</span>}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Popular Tools */}
      <section style={{ padding: '0 16px 80px', background: '#0d140d' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', paddingTop: 60 }}>
          <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 28, fontWeight: 700, marginBottom: 8 }}>Most Popular Tools</h2>
          <p style={{ color: '#6b8f6b', marginBottom: 40 }}>The tools our users love most</p>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 12 }}>
            {allTools.slice(0, 12).map(tool => (
              <Link key={tool.id} href={`/tools/${tool.id}`}>
                <div className="tool-card" style={{ background: '#0a0f0a', borderRadius: 12, padding: 16, cursor: 'pointer' }}>
                  <span style={{ fontSize: 20 }}>{tool.categoryIcon}</span>
                  <h3 style={{ fontFamily: 'Syne, sans-serif', fontWeight: 600, fontSize: 14, color: '#e2f0e2', margin: '8px 0 4px' }}>{tool.name}</h3>
                  <p style={{ color: '#6b8f6b', fontSize: 12, margin: 0, lineHeight: 1.4 }}>{tool.desc}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Why FreeToolHub */}
      <section style={{ padding: '60px 16px 80px' }}>
        <div style={{ maxWidth: 900, margin: '0 auto', textAlign: 'center' }}>
          <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 28, fontWeight: 700, marginBottom: 40 }}>Why FreeToolHub?</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 24 }}>
            {[
              ['🔒', 'Privacy First', 'Files processed in your browser. Nothing uploaded to servers.'],
              ['⚡', 'Lightning Fast', 'All tools work instantly. No waiting, no loading.'],
              ['📱', 'Works Everywhere', 'Desktop, tablet or mobile — works on all devices.'],
              ['🆓', 'Always Free', 'No hidden fees, no premium plans, no signup needed.'],
            ].map(([icon, title, desc]) => (
              <div key={title as string} style={{ background: '#111a11', border: '1px solid #1a2e1a', borderRadius: 16, padding: 24 }}>
                <div style={{ fontSize: 32, marginBottom: 12 }}>{icon}</div>
                <h3 style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, color: '#e2f0e2', marginBottom: 8, fontSize: 16 }}>{title as string}</h3>
                <p style={{ color: '#6b8f6b', fontSize: 13, lineHeight: 1.6, margin: 0 }}>{desc as string}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}

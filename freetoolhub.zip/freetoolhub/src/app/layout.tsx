import type { Metadata } from 'next'
import '@/styles/globals.css'
import Layout from '@/components/Layout'

export const metadata: Metadata = {
  title: 'FreeToolHub - Free Online Tools for Images, Text, Developers & More',
  description: 'Free online tools: image compressor, JSON formatter, password generator, word counter, PDF tools and 80+ more. No signup, no limits.',
  keywords: 'free online tools, image compressor, json formatter, password generator, word counter, pdf tools',
  openGraph: {
    title: 'FreeToolHub - 80+ Free Online Tools',
    description: 'Free online tools for images, text, developers, SEO and more.',
    url: 'https://freetoolhub.com',
    siteName: 'FreeToolHub',
    type: 'website',
  },
  twitter: { card: 'summary_large_image', title: 'FreeToolHub', description: 'Free online tools' },
  robots: 'index, follow',
  verification: { google: 'YOUR_GOOGLE_VERIFICATION_CODE' }
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        {/* AdSense */}
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-XXXXXXXXXXXXXXXX" crossOrigin="anonymous"></script>
      </head>
      <body>
        <Layout>{children}</Layout>
      </body>
    </html>
  )
}

import { getAllTools, CATEGORIES } from '@/lib/tools'

export default function sitemap() {
  const tools = getAllTools()
  const baseUrl = 'https://freetoolhub.com'
  const staticPages = ['', '/tools', '/blog', '/about', '/contact', '/privacy-policy'].map(path => ({
    url: `${baseUrl}${path}`,
    lastModified: new Date(),
    changeFrequency: 'weekly' as const,
    priority: path === '' ? 1 : 0.8,
  }))
  const toolPages = tools.map(tool => ({
    url: `${baseUrl}/tools/${tool.id}`,
    lastModified: new Date(),
    changeFrequency: 'monthly' as const,
    priority: 0.7,
  }))
  return [...staticPages, ...toolPages]
}

// src/app/about/page.tsx
export const metadata = { title: 'About FreeToolHub — Free Online Tools', description: 'Learn about FreeToolHub, your go-to platform for free online tools.' }
export default function AboutPage() {
  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '60px 16px' }}>
      <h1 style={{ fontFamily: 'Syne, sans-serif', fontSize: 36, fontWeight: 800, marginBottom: 24 }}>About FreeToolHub</h1>
      <div style={{ color: '#6b8f6b', lineHeight: 1.9, fontSize: 16 }}>
        <p>FreeToolHub is a collection of 80+ free online tools designed to make your digital life easier. From image compression to JSON formatting, from password generation to PDF manipulation — we have the tools you need, completely free.</p>
        <h2 style={{ fontFamily: 'Syne, sans-serif', color: '#e2f0e2', marginTop: 32, marginBottom: 16 }}>Our Mission</h2>
        <p>We believe powerful tools should be accessible to everyone — students, developers, designers, content creators and businesses of all sizes. That's why every tool on FreeToolHub is completely free with no signup required.</p>
        <h2 style={{ fontFamily: 'Syne, sans-serif', color: '#e2f0e2', marginTop: 32, marginBottom: 16 }}>Privacy First</h2>
        <p>Most of our tools process files directly in your browser. This means your files never leave your device and are never uploaded to our servers. Your privacy is our priority.</p>
        <h2 style={{ fontFamily: 'Syne, sans-serif', color: '#e2f0e2', marginTop: 32, marginBottom: 16 }}>What We Offer</h2>
        <ul style={{ paddingLeft: 20 }}>
          {['🖼️ Image Tools — Compress, convert, resize and edit images', '✍️ Text Tools — Word counter, case converter, text utilities', '👨‍💻 Developer Tools — JSON formatter, Base64, UUID generator', '📄 PDF Tools — Merge, split, compress PDF files', '🔐 Security Tools — Password generator, strength checker', '🔎 SEO Tools — Meta analyzer, robots.txt generator', '📊 Calculator Tools — BMI, age, loan calculators'].map(item => (
            <li key={item} style={{ marginBottom: 8 }}>{item}</li>
          ))}
        </ul>
      </div>
    </div>
  )
}

'use client'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import { getToolById, CATEGORIES } from '@/lib/tools'

// ============ TOOL IMPLEMENTATIONS ============

function WordCounter() {
  const [text, setText] = useState('')
  const words = text.trim() ? text.trim().split(/\s+/).length : 0
  const chars = text.length
  const charsNoSpace = text.replace(/\s/g, '').length
  const sentences = text.split(/[.!?]+/).filter(Boolean).length
  const paragraphs = text.split(/\n\n+/).filter(Boolean).length
  const readTime = Math.ceil(words / 200)
  return (
    <div>
      <textarea className="tool-input" placeholder="Paste or type your text here..." value={text} onChange={e => setText(e.target.value)} style={{ minHeight: 200 }} />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(120px, 1fr))', gap: 12, marginTop: 16 }}>
        {[['Words', words], ['Characters', chars], ['No Spaces', charsNoSpace], ['Sentences', sentences], ['Paragraphs', paragraphs], ['Read Time', `${readTime} min`]].map(([label, val]) => (
          <div key={label as string} style={{ background: '#0a0f0a', border: '1px solid #1a2e1a', borderRadius: 10, padding: 16, textAlign: 'center' }}>
            <div style={{ fontSize: 24, fontWeight: 700, color: '#22c55e', fontFamily: 'Syne, sans-serif' }}>{val}</div>
            <div style={{ fontSize: 12, color: '#6b8f6b', marginTop: 4 }}>{label as string}</div>
          </div>
        ))}
      </div>
    </div>
  )
}

function CaseConverter() {
  const [text, setText] = useState('')
  const [result, setResult] = useState('')
  const convert = (type: string) => {
    switch (type) {
      case 'upper': setResult(text.toUpperCase()); break
      case 'lower': setResult(text.toLowerCase()); break
      case 'title': setResult(text.replace(/\w\S*/g, t => t.charAt(0).toUpperCase() + t.substring(1).toLowerCase())); break
      case 'sentence': setResult(text.charAt(0).toUpperCase() + text.slice(1).toLowerCase()); break
      case 'toggle': setResult(text.split('').map(c => c === c.toUpperCase() ? c.toLowerCase() : c.toUpperCase()).join('')); break
    }
  }
  return (
    <div>
      <textarea className="tool-input" placeholder="Enter your text here..." value={text} onChange={e => setText(e.target.value)} />
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 12 }}>
        {[['upper', 'UPPERCASE'], ['lower', 'lowercase'], ['title', 'Title Case'], ['sentence', 'Sentence case'], ['toggle', 'tOGGLE cASE']].map(([type, label]) => (
          <button key={type} className="btn-secondary" style={{ fontSize: 13, padding: '8px 14px' }} onClick={() => convert(type)}>{label}</button>
        ))}
      </div>
      {result && (
        <div style={{ marginTop: 16 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span style={{ fontSize: 13, color: '#6b8f6b' }}>Result:</span>
            <button className="btn-secondary" style={{ fontSize: 12, padding: '4px 10px' }} onClick={() => { navigator.clipboard.writeText(result) }}>Copy</button>
          </div>
          <textarea className="tool-input" value={result} readOnly style={{ minHeight: 100 }} />
        </div>
      )}
    </div>
  )
}

function JsonFormatter() {
  const [input, setInput] = useState('')
  const [output, setOutput] = useState('')
  const [error, setError] = useState('')
  const format = () => {
    try { setOutput(JSON.stringify(JSON.parse(input), null, 2)); setError('') }
    catch (e: any) { setError(e.message) }
  }
  const minify = () => {
    try { setOutput(JSON.stringify(JSON.parse(input))); setError('') }
    catch (e: any) { setError(e.message) }
  }
  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        <div>
          <p style={{ fontSize: 13, color: '#6b8f6b', marginBottom: 8 }}>Input JSON</p>
          <textarea className="tool-input" placeholder='{"key": "value"}' value={input} onChange={e => setInput(e.target.value)} style={{ minHeight: 250, fontFamily: 'JetBrains Mono, monospace', fontSize: 13 }} />
        </div>
        <div>
          <p style={{ fontSize: 13, color: '#6b8f6b', marginBottom: 8 }}>Formatted Output</p>
          <textarea className="tool-input" value={output} readOnly style={{ minHeight: 250, fontFamily: 'JetBrains Mono, monospace', fontSize: 13 }} />
        </div>
      </div>
      {error && <p style={{ color: '#f87171', fontSize: 13, marginTop: 8 }}>❌ {error}</p>}
      <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
        <button className="btn-primary" onClick={format}>Format / Beautify</button>
        <button className="btn-secondary" onClick={minify}>Minify</button>
        <button className="btn-secondary" onClick={() => navigator.clipboard.writeText(output)}>Copy Output</button>
      </div>
    </div>
  )
}

function Base64Tool({ mode }: { mode: 'encode' | 'decode' }) {
  const [input, setInput] = useState('')
  const [output, setOutput] = useState('')
  const [error, setError] = useState('')
  const process = () => {
    try {
      if (mode === 'encode') setOutput(btoa(unescape(encodeURIComponent(input))))
      else setOutput(decodeURIComponent(escape(atob(input))))
      setError('')
    } catch { setError('Invalid input') }
  }
  return (
    <div>
      <p style={{ fontSize: 13, color: '#6b8f6b', marginBottom: 8 }}>{mode === 'encode' ? 'Text to encode:' : 'Base64 to decode:'}</p>
      <textarea className="tool-input" placeholder={mode === 'encode' ? 'Enter text...' : 'Enter Base64 string...'} value={input} onChange={e => setInput(e.target.value)} />
      <button className="btn-primary" style={{ marginTop: 12 }} onClick={process}>{mode === 'encode' ? 'Encode to Base64' : 'Decode from Base64'}</button>
      {error && <p style={{ color: '#f87171', fontSize: 13, marginTop: 8 }}>❌ {error}</p>}
      {output && (
        <div style={{ marginTop: 16 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span style={{ fontSize: 13, color: '#6b8f6b' }}>Result:</span>
            <button className="btn-secondary" style={{ fontSize: 12, padding: '4px 10px' }} onClick={() => navigator.clipboard.writeText(output)}>Copy</button>
          </div>
          <textarea className="tool-input" value={output} readOnly style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 13 }} />
        </div>
      )}
    </div>
  )
}

function PasswordGenerator() {
  const [length, setLength] = useState(16)
  const [options, setOptions] = useState({ upper: true, lower: true, numbers: true, symbols: true })
  const [password, setPassword] = useState('')
  const [strength, setStrength] = useState('')
  const generate = () => {
    let chars = ''
    if (options.upper) chars += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    if (options.lower) chars += 'abcdefghijklmnopqrstuvwxyz'
    if (options.numbers) chars += '0123456789'
    if (options.symbols) chars += '!@#$%^&*()_+-=[]{}|;:,.<>?'
    if (!chars) return
    let pwd = ''
    for (let i = 0; i < length; i++) pwd += chars[Math.floor(Math.random() * chars.length)]
    setPassword(pwd)
    const score = [options.upper, options.lower, options.numbers, options.symbols].filter(Boolean).length
    setStrength(score <= 2 ? 'Weak' : score === 3 ? 'Medium' : 'Strong')
  }
  const strengthColor = { Weak: '#f87171', Medium: '#fbbf24', Strong: '#22c55e' }[strength] || '#6b8f6b'
  return (
    <div>
      <div style={{ marginBottom: 16 }}>
        <label style={{ fontSize: 13, color: '#6b8f6b', display: 'block', marginBottom: 8 }}>Length: {length}</label>
        <input type="range" min={8} max={64} value={length} onChange={e => setLength(Number(e.target.value))} style={{ width: '100%', accentColor: '#22c55e' }} />
      </div>
      <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', marginBottom: 16 }}>
        {([['upper', 'Uppercase (A-Z)'], ['lower', 'Lowercase (a-z)'], ['numbers', 'Numbers (0-9)'], ['symbols', 'Symbols (!@#)']]).map(([key, label]) => (
          <label key={key} style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', fontSize: 14, color: '#e2f0e2' }}>
            <input type="checkbox" checked={(options as any)[key]} onChange={e => setOptions({ ...options, [key]: e.target.checked })} style={{ accentColor: '#22c55e' }} />
            {label}
          </label>
        ))}
      </div>
      <button className="btn-primary" onClick={generate}>Generate Password</button>
      {password && (
        <div style={{ marginTop: 16 }}>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <input className="tool-input" value={password} readOnly style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 16, letterSpacing: 2 }} />
            <button className="btn-secondary" style={{ padding: '12px 16px', whiteSpace: 'nowrap' }} onClick={() => navigator.clipboard.writeText(password)}>Copy</button>
          </div>
          {strength && <p style={{ fontSize: 13, marginTop: 8 }}>Strength: <span style={{ color: strengthColor, fontWeight: 600 }}>{strength}</span></p>}
        </div>
      )}
    </div>
  )
}

function UuidGenerator() {
  const [uuids, setUuids] = useState<string[]>([])
  const [count, setCount] = useState(5)
  const generate = () => {
    const list = []
    for (let i = 0; i < count; i++) {
      list.push('xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
        const r = Math.random() * 16 | 0
        return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16)
      }))
    }
    setUuids(list)
  }
  return (
    <div>
      <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 16 }}>
        <label style={{ fontSize: 13, color: '#6b8f6b' }}>Count:</label>
        <input type="number" min={1} max={50} value={count} onChange={e => setCount(Number(e.target.value))} className="tool-input" style={{ width: 80 }} />
        <button className="btn-primary" onClick={generate}>Generate UUIDs</button>
      </div>
      {uuids.length > 0 && (
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span style={{ fontSize: 13, color: '#6b8f6b' }}>{uuids.length} UUIDs generated</span>
            <button className="btn-secondary" style={{ fontSize: 12, padding: '4px 10px' }} onClick={() => navigator.clipboard.writeText(uuids.join('\n'))}>Copy All</button>
          </div>
          <textarea className="tool-input" value={uuids.join('\n')} readOnly style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 13, minHeight: 200 }} />
        </div>
      )}
    </div>
  )
}

function HashGenerator() {
  const [input, setInput] = useState('')
  const [hashes, setHashes] = useState<{ [key: string]: string }>({})
  const generate = async () => {
    const encoder = new TextEncoder()
    const data = encoder.encode(input)
    const results: { [key: string]: string } = {}
    for (const algo of ['SHA-1', 'SHA-256', 'SHA-512']) {
      const hashBuffer = await crypto.subtle.digest(algo, data)
      const hashArray = Array.from(new Uint8Array(hashBuffer))
      results[algo] = hashArray.map(b => b.toString(16).padStart(2, '0')).join('')
    }
    setHashes(results)
  }
  return (
    <div>
      <textarea className="tool-input" placeholder="Enter text to hash..." value={input} onChange={e => setInput(e.target.value)} />
      <button className="btn-primary" style={{ marginTop: 12 }} onClick={generate}>Generate Hashes</button>
      {Object.entries(hashes).map(([algo, hash]) => (
        <div key={algo} style={{ marginTop: 16 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
            <span style={{ fontSize: 13, color: '#22c55e', fontWeight: 600 }}>{algo}</span>
            <button className="btn-secondary" style={{ fontSize: 12, padding: '4px 10px' }} onClick={() => navigator.clipboard.writeText(hash)}>Copy</button>
          </div>
          <div style={{ background: '#0a0f0a', border: '1px solid #1a2e1a', borderRadius: 8, padding: '10px 14px', fontFamily: 'JetBrains Mono, monospace', fontSize: 12, color: '#e2f0e2', wordBreak: 'break-all' }}>{hash}</div>
        </div>
      ))}
    </div>
  )
}

function UrlEncoderDecoder({ mode }: { mode: 'encode' | 'decode' }) {
  const [input, setInput] = useState('')
  const [output, setOutput] = useState('')
  const process = () => {
    try {
      setOutput(mode === 'encode' ? encodeURIComponent(input) : decodeURIComponent(input))
    } catch { setOutput('Invalid input') }
  }
  return (
    <div>
      <textarea className="tool-input" placeholder={mode === 'encode' ? 'Enter URL to encode...' : 'Enter encoded URL to decode...'} value={input} onChange={e => setInput(e.target.value)} />
      <button className="btn-primary" style={{ marginTop: 12 }} onClick={process}>{mode === 'encode' ? 'Encode URL' : 'Decode URL'}</button>
      {output && (
        <div style={{ marginTop: 16 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span style={{ fontSize: 13, color: '#6b8f6b' }}>Result:</span>
            <button className="btn-secondary" style={{ fontSize: 12, padding: '4px 10px' }} onClick={() => navigator.clipboard.writeText(output)}>Copy</button>
          </div>
          <textarea className="tool-input" value={output} readOnly />
        </div>
      )}
    </div>
  )
}

function AgeCalculator() {
  const [dob, setDob] = useState('')
  const [result, setResult] = useState<any>(null)
  const calculate = () => {
    const birth = new Date(dob)
    const now = new Date()
    let years = now.getFullYear() - birth.getFullYear()
    let months = now.getMonth() - birth.getMonth()
    let days = now.getDate() - birth.getDate()
    if (days < 0) { months--; days += 30 }
    if (months < 0) { years--; months += 12 }
    const totalDays = Math.floor((now.getTime() - birth.getTime()) / (1000 * 60 * 60 * 24))
    setResult({ years, months, days, totalDays, totalWeeks: Math.floor(totalDays / 7) })
  }
  return (
    <div>
      <label style={{ fontSize: 13, color: '#6b8f6b', display: 'block', marginBottom: 8 }}>Date of Birth:</label>
      <input type="date" className="tool-input" style={{ maxWidth: 250 }} value={dob} onChange={e => setDob(e.target.value)} />
      <button className="btn-primary" style={{ marginTop: 12, display: 'block' }} onClick={calculate}>Calculate Age</button>
      {result && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: 12, marginTop: 20 }}>
          {[['Years', result.years], ['Months', result.months], ['Days', result.days], ['Total Days', result.totalDays.toLocaleString()], ['Total Weeks', result.totalWeeks.toLocaleString()]].map(([label, val]) => (
            <div key={label as string} style={{ background: '#0a0f0a', border: '1px solid #1a2e1a', borderRadius: 10, padding: 16, textAlign: 'center' }}>
              <div style={{ fontSize: 28, fontWeight: 700, color: '#22c55e', fontFamily: 'Syne, sans-serif' }}>{val}</div>
              <div style={{ fontSize: 12, color: '#6b8f6b', marginTop: 4 }}>{label as string}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function BmiCalculator() {
  const [weight, setWeight] = useState('')
  const [height, setHeight] = useState('')
  const [unit, setUnit] = useState('metric')
  const [result, setResult] = useState<any>(null)
  const calculate = () => {
    let bmi: number
    if (unit === 'metric') bmi = Number(weight) / Math.pow(Number(height) / 100, 2)
    else bmi = (703 * Number(weight)) / Math.pow(Number(height), 2)
    bmi = Math.round(bmi * 10) / 10
    let category = ''
    let color = ''
    if (bmi < 18.5) { category = 'Underweight'; color = '#60a5fa' }
    else if (bmi < 25) { category = 'Normal Weight'; color = '#22c55e' }
    else if (bmi < 30) { category = 'Overweight'; color = '#fbbf24' }
    else { category = 'Obese'; color = '#f87171' }
    setResult({ bmi, category, color })
  }
  return (
    <div>
      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        {['metric', 'imperial'].map(u => (
          <button key={u} className={unit === u ? 'btn-primary' : 'btn-secondary'} style={{ fontSize: 13, padding: '8px 16px' }} onClick={() => setUnit(u)}>
            {u === 'metric' ? 'Metric (kg/cm)' : 'Imperial (lbs/in)'}
          </button>
        ))}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16 }}>
        <div>
          <label style={{ fontSize: 13, color: '#6b8f6b', display: 'block', marginBottom: 6 }}>Weight ({unit === 'metric' ? 'kg' : 'lbs'})</label>
          <input className="tool-input" type="number" placeholder="70" value={weight} onChange={e => setWeight(e.target.value)} />
        </div>
        <div>
          <label style={{ fontSize: 13, color: '#6b8f6b', display: 'block', marginBottom: 6 }}>Height ({unit === 'metric' ? 'cm' : 'inches'})</label>
          <input className="tool-input" type="number" placeholder="175" value={height} onChange={e => setHeight(e.target.value)} />
        </div>
      </div>
      <button className="btn-primary" onClick={calculate}>Calculate BMI</button>
      {result && (
        <div style={{ marginTop: 20, background: '#0a0f0a', border: '1px solid #1a2e1a', borderRadius: 12, padding: 24, textAlign: 'center' }}>
          <div style={{ fontSize: 56, fontWeight: 800, color: result.color, fontFamily: 'Syne, sans-serif' }}>{result.bmi}</div>
          <div style={{ fontSize: 18, color: result.color, fontWeight: 600, marginTop: 8 }}>{result.category}</div>
        </div>
      )}
    </div>
  )
}

function LoremIpsum() {
  const [count, setCount] = useState(3)
  const [type, setType] = useState('paragraphs')
  const [output, setOutput] = useState('')
  const words = ['lorem', 'ipsum', 'dolor', 'sit', 'amet', 'consectetur', 'adipiscing', 'elit', 'sed', 'do', 'eiusmod', 'tempor', 'incididunt', 'ut', 'labore', 'et', 'dolore', 'magna', 'aliqua', 'enim', 'quis', 'nostrud', 'exercitation', 'ullamco', 'laboris', 'nisi', 'aliquip', 'commodo', 'consequat', 'duis', 'aute', 'irure', 'in', 'reprehenderit', 'voluptate', 'velit', 'esse', 'cillum', 'eu', 'fugiat', 'nulla', 'pariatur', 'excepteur', 'sint', 'occaecat', 'cupidatat', 'non', 'proident', 'sunt', 'culpa', 'qui', 'officia', 'deserunt', 'mollit', 'anim', 'id', 'est', 'laborum']
  const generate = () => {
    const getWord = () => words[Math.floor(Math.random() * words.length)]
    const getSentence = () => { let s = ''; for (let i = 0; i < 8 + Math.floor(Math.random() * 10); i++) s += (i === 0 ? getWord().charAt(0).toUpperCase() + getWord().slice(1) : getWord()) + (i < 7 ? ' ' : ''); return s + '.'; }
    const getParagraph = () => { let p = ''; for (let i = 0; i < 4 + Math.floor(Math.random() * 4); i++) p += getSentence() + ' '; return p.trim(); }
    if (type === 'words') setOutput(Array.from({ length: count }, getWord).join(' '))
    else if (type === 'sentences') setOutput(Array.from({ length: count }, getSentence).join(' '))
    else setOutput(Array.from({ length: count }, getParagraph).join('\n\n'))
  }
  return (
    <div>
      <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap', marginBottom: 16 }}>
        <select className="tool-input" style={{ width: 'auto' }} value={type} onChange={e => setType(e.target.value)}>
          <option value="paragraphs">Paragraphs</option>
          <option value="sentences">Sentences</option>
          <option value="words">Words</option>
        </select>
        <input type="number" className="tool-input" style={{ width: 80 }} min={1} max={20} value={count} onChange={e => setCount(Number(e.target.value))} />
        <button className="btn-primary" onClick={generate}>Generate</button>
      </div>
      {output && (
        <div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 8 }}>
            <button className="btn-secondary" style={{ fontSize: 12, padding: '4px 10px' }} onClick={() => navigator.clipboard.writeText(output)}>Copy</button>
          </div>
          <textarea className="tool-input" value={output} readOnly style={{ minHeight: 200 }} />
        </div>
      )}
    </div>
  )
}

function ReverseText() {
  const [text, setText] = useState('')
  const reversed = text.split('').reverse().join('')
  const reversedWords = text.split(' ').reverse().join(' ')
  return (
    <div>
      <textarea className="tool-input" placeholder="Enter text to reverse..." value={text} onChange={e => setText(e.target.value)} />
      {text && (
        <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 16 }}>
          {[['Reversed Characters', reversed], ['Reversed Words', reversedWords]].map(([label, val]) => (
            <div key={label as string}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                <span style={{ fontSize: 13, color: '#6b8f6b' }}>{label as string}:</span>
                <button className="btn-secondary" style={{ fontSize: 12, padding: '4px 10px' }} onClick={() => navigator.clipboard.writeText(val as string)}>Copy</button>
              </div>
              <textarea className="tool-input" value={val as string} readOnly style={{ minHeight: 80 }} />
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function TextToSlug() {
  const [text, setText] = useState('')
  const slug = text.toLowerCase().trim().replace(/[^\w\s-]/g, '').replace(/[\s_-]+/g, '-').replace(/^-+|-+$/g, '')
  return (
    <div>
      <input className="tool-input" placeholder="Enter text to convert to slug..." value={text} onChange={e => setText(e.target.value)} />
      {slug && (
        <div style={{ marginTop: 16 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span style={{ fontSize: 13, color: '#6b8f6b' }}>Slug:</span>
            <button className="btn-secondary" style={{ fontSize: 12, padding: '4px 10px' }} onClick={() => navigator.clipboard.writeText(slug)}>Copy</button>
          </div>
          <div style={{ background: '#0a0f0a', border: '1px solid #22c55e40', borderRadius: 8, padding: '12px 16px', fontFamily: 'JetBrains Mono, monospace', color: '#22c55e', fontSize: 16 }}>{slug}</div>
        </div>
      )}
    </div>
  )
}

function PercentageCalc() {
  const [a, setA] = useState('')
  const [b, setB] = useState('')
  return (
    <div>
      <div style={{ display: 'grid', gap: 24 }}>
        {[
          ['What is X% of Y?', `${Number(a) * Number(b) / 100}`, 'X', 'Y'],
          ['X is what % of Y?', `${(Number(a) / Number(b) * 100).toFixed(2)}%`, 'X', 'Y'],
        ].map(([label, result, la, lb]) => (
          <div key={label as string} style={{ background: '#0a0f0a', border: '1px solid #1a2e1a', borderRadius: 12, padding: 20 }}>
            <h3 style={{ fontFamily: 'Syne, sans-serif', fontSize: 15, color: '#e2f0e2', marginBottom: 16 }}>{label as string}</h3>
            <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
              <input className="tool-input" style={{ width: 100 }} placeholder={la as string} value={a} onChange={e => setA(e.target.value)} />
              <span style={{ color: '#6b8f6b' }}>%  of</span>
              <input className="tool-input" style={{ width: 100 }} placeholder={lb as string} value={b} onChange={e => setB(e.target.value)} />
              <span style={{ color: '#6b8f6b' }}>=</span>
              <span style={{ color: '#22c55e', fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 20 }}>{a && b ? result : '?'}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

function ImageCompressor() {
  const [preview, setPreview] = useState('')
  const [info, setInfo] = useState('')
  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const originalSize = (file.size / 1024).toFixed(1)
    const reader = new FileReader()
    reader.onload = ev => {
      const img = new Image()
      img.onload = () => {
        const canvas = document.createElement('canvas')
        const scale = Math.min(1, 1200 / Math.max(img.width, img.height))
        canvas.width = img.width * scale
        canvas.height = img.height * scale
        const ctx = canvas.getContext('2d')!
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
        const compressed = canvas.toDataURL('image/jpeg', 0.7)
        setPreview(compressed)
        const newSize = ((compressed.length * 3 / 4) / 1024).toFixed(1)
        const saving = (100 - (Number(newSize) / Number(originalSize)) * 100).toFixed(0)
        setInfo(`Original: ${originalSize}KB → Compressed: ${newSize}KB (${saving}% saved)`)
      }
      img.src = ev.target?.result as string
    }
    reader.readAsDataURL(file)
  }
  const download = () => {
    const a = document.createElement('a')
    a.href = preview
    a.download = 'compressed.jpg'
    a.click()
  }
  return (
    <div>
      <label style={{ display: 'block', border: '2px dashed #1a2e1a', borderRadius: 12, padding: 40, textAlign: 'center', cursor: 'pointer' }}>
        <input type="file" accept="image/*" onChange={handleFile} style={{ display: 'none' }} />
        <div style={{ fontSize: 40, marginBottom: 12 }}>🖼️</div>
        <div style={{ color: '#6b8f6b' }}>Click to upload image or drag & drop</div>
        <div style={{ fontSize: 12, color: '#6b8f6b', marginTop: 4 }}>JPG, PNG, WebP supported</div>
      </label>
      {preview && (
        <div style={{ marginTop: 20 }}>
          {info && <p style={{ color: '#22c55e', fontSize: 14, marginBottom: 12, fontWeight: 600 }}>✅ {info}</p>}
          <img src={preview} alt="Compressed" style={{ maxWidth: '100%', borderRadius: 8, marginBottom: 12 }} />
          <button className="btn-primary" onClick={download}>⬇️ Download Compressed Image</button>
        </div>
      )}
    </div>
  )
}

function ImageResizer() {
  const [preview, setPreview] = useState('')
  const [width, setWidth] = useState(800)
  const [height, setHeight] = useState(600)
  const [srcImg, setSrcImg] = useState<HTMLImageElement | null>(null)
  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = ev => {
      const img = new Image()
      img.onload = () => { setSrcImg(img); setWidth(img.width); setHeight(img.height) }
      img.src = ev.target?.result as string
    }
    reader.readAsDataURL(file)
  }
  const resize = () => {
    if (!srcImg) return
    const canvas = document.createElement('canvas')
    canvas.width = width; canvas.height = height
    canvas.getContext('2d')!.drawImage(srcImg, 0, 0, width, height)
    setPreview(canvas.toDataURL('image/jpeg', 0.9))
  }
  return (
    <div>
      <label style={{ display: 'block', border: '2px dashed #1a2e1a', borderRadius: 12, padding: 32, textAlign: 'center', cursor: 'pointer', marginBottom: 16 }}>
        <input type="file" accept="image/*" onChange={handleFile} style={{ display: 'none' }} />
        <div style={{ color: '#6b8f6b' }}>📁 Click to upload image</div>
      </label>
      {srcImg && (
        <div>
          <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap', marginBottom: 16 }}>
            <div><label style={{ fontSize: 13, color: '#6b8f6b' }}>Width (px)</label><input className="tool-input" type="number" value={width} onChange={e => setWidth(Number(e.target.value))} style={{ width: 100 }} /></div>
            <div><label style={{ fontSize: 13, color: '#6b8f6b' }}>Height (px)</label><input className="tool-input" type="number" value={height} onChange={e => setHeight(Number(e.target.value))} style={{ width: 100 }} /></div>
            <button className="btn-primary" style={{ alignSelf: 'flex-end' }} onClick={resize}>Resize</button>
          </div>
          {preview && (
            <div>
              <img src={preview} alt="Resized" style={{ maxWidth: '100%', borderRadius: 8, marginBottom: 12 }} />
              <button className="btn-secondary" onClick={() => { const a = document.createElement('a'); a.href = preview; a.download = `resized_${width}x${height}.jpg`; a.click() }}>⬇️ Download</button>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

function GenericTool({ name }: { name: string }) {
  return (
    <div style={{ textAlign: 'center', padding: '40px 20px' }}>
      <div style={{ fontSize: 48, marginBottom: 16 }}>🔧</div>
      <h3 style={{ fontFamily: 'Syne, sans-serif', color: '#e2f0e2', marginBottom: 12 }}>{name}</h3>
      <p style={{ color: '#6b8f6b', fontSize: 15, lineHeight: 1.7 }}>
        This tool is coming soon! We're working hard to bring you the best free online tools.
        Check back soon or explore our other available tools.
      </p>
      <Link href="/tools">
        <button className="btn-primary" style={{ marginTop: 24 }}>Browse Available Tools</button>
      </Link>
    </div>
  )
}

// ============ TOOL ROUTER ============
function ToolRenderer({ toolId, toolName }: { toolId: string, toolName: string }) {
  switch (toolId) {
    case 'word-counter': return <WordCounter />
    case 'character-counter': return <WordCounter />
    case 'case-converter': return <CaseConverter />
    case 'json-formatter': return <JsonFormatter />
    case 'json-validator': return <JsonFormatter />
    case 'base64-encode': return <Base64Tool mode="encode" />
    case 'base64-decode': return <Base64Tool mode="decode" />
    case 'image-to-base64': return <Base64Tool mode="encode" />
    case 'password-generator': return <PasswordGenerator />
    case 'uuid-generator': return <UuidGenerator />
    case 'hash-generator': return <HashGenerator />
    case 'url-encoder': return <UrlEncoderDecoder mode="encode" />
    case 'url-decoder': return <UrlEncoderDecoder mode="decode" />
    case 'age-calculator': return <AgeCalculator />
    case 'bmi-calculator': return <BmiCalculator />
    case 'lorem-ipsum': return <LoremIpsum />
    case 'reverse-text': return <ReverseText />
    case 'text-to-slug': return <TextToSlug />
    case 'percentage-calculator': return <PercentageCalc />
    case 'image-compressor': return <ImageCompressor />
    case 'resize-image': return <ImageResizer />
    default: return <GenericTool name={toolName} />
  }
}

export default function ToolPage({ params }: { params: { id: string } }) {
  const tool = getToolById(params.id)
  if (!tool) return <div style={{ padding: 60, textAlign: 'center', color: '#6b8f6b' }}>Tool not found. <Link href="/tools" style={{ color: '#22c55e' }}>Browse all tools</Link></div>

  const cat = CATEGORIES.find(c => c.id === tool.category)
  const relatedTools = cat?.tools.filter(t => t.id !== tool.id).slice(0, 6) || []

  return (
    <div style={{ maxWidth: 900, margin: '0 auto', padding: '40px 16px' }}>
      {/* Breadcrumb */}
      <div style={{ fontSize: 13, color: '#6b8f6b', marginBottom: 24 }}>
        <Link href="/" style={{ color: '#6b8f6b', textDecoration: 'none' }}>Home</Link>
        <span style={{ margin: '0 8px' }}>›</span>
        <Link href="/tools" style={{ color: '#6b8f6b', textDecoration: 'none' }}>Tools</Link>
        <span style={{ margin: '0 8px' }}>›</span>
        <span style={{ color: '#22c55e' }}>{tool.name}</span>
      </div>

      {/* Header */}
      <div style={{ marginBottom: 32 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
          <span style={{ fontSize: 32 }}>{tool.categoryIcon}</span>
          <div>
            <h1 style={{ fontFamily: 'Syne, sans-serif', fontSize: 28, fontWeight: 800, color: '#e2f0e2', margin: 0 }}>{tool.name}</h1>
            <p style={{ color: '#6b8f6b', margin: '4px 0 0', fontSize: 15 }}>{tool.desc}</p>
          </div>
        </div>
        <div className="tag">🆓 Free • No signup • Instant results</div>
      </div>

      {/* AdSense top */}
      <div className="adsense-slot" style={{ marginBottom: 24 }}>Ad</div>

      {/* Tool */}
      <div className="tool-area">
        <ToolRenderer toolId={params.id} toolName={tool.name} />
      </div>

      {/* AdSense bottom */}
      <div className="adsense-slot" style={{ marginTop: 24, marginBottom: 40 }}>Ad</div>

      {/* How to use */}
      <div style={{ background: '#111a11', border: '1px solid #1a2e1a', borderRadius: 16, padding: 28, marginBottom: 32 }}>
        <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 20, fontWeight: 700, marginBottom: 16 }}>How to Use {tool.name}</h2>
        <ol style={{ color: '#6b8f6b', lineHeight: 2, paddingLeft: 20 }}>
          <li>Open the {tool.name} tool above</li>
          <li>Upload your file or enter your text/data</li>
          <li>Click the action button to process</li>
          <li>Download or copy the result instantly</li>
          <li>No signup or registration required — completely free!</li>
        </ol>
      </div>

      {/* Related tools */}
      {relatedTools.length > 0 && (
        <div>
          <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 20, fontWeight: 700, marginBottom: 16 }}>Related Tools</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 12 }}>
            {relatedTools.map(t => (
              <Link key={t.id} href={`/tools/${t.id}`}>
                <div className="tool-card" style={{ background: '#111a11', borderRadius: 12, padding: 14, cursor: 'pointer' }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: '#22c55e', marginBottom: 4, fontFamily: 'Syne, sans-serif' }}>{t.name}</div>
                  <div style={{ fontSize: 12, color: '#6b8f6b' }}>{t.desc}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

import Link from 'next/link'
import { CATEGORIES, getAllTools } from '@/lib/tools'

export const metadata = {
  title: 'All Free Online Tools — FreeToolHub',
  description: 'Browse all 80+ free online tools: image tools, developer tools, text tools, PDF tools, SEO tools and more. No signup required.',
}

export default function ToolsPage() {
  return (
    <div style={{ maxWidth: 1200, margin: '0 auto', padding: '60px 16px' }}>
      <h1 style={{ fontFamily: 'Syne, sans-serif', fontSize: 36, fontWeight: 800, marginBottom: 8 }}>All Tools</h1>
      <p style={{ color: '#6b8f6b', marginBottom: 48, fontSize: 16 }}>80+ free online tools — no signup, no limits</p>

      {CATEGORIES.map(cat => (
        <div key={cat.id} style={{ marginBottom: 56 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24, paddingBottom: 12, borderBottom: '1px solid #1a2e1a' }}>
            <span style={{ fontSize: 24 }}>{cat.icon}</span>
            <div>
              <h2 style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 20, color: '#e2f0e2', margin: 0 }}>{cat.name}</h2>
              <p style={{ color: '#6b8f6b', fontSize: 13, margin: 0 }}>{cat.description}</p>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 12 }}>
            {cat.tools.map(tool => (
              <Link key={tool.id} href={`/tools/${tool.id}`}>
                <div className="tool-card" style={{ background: '#111a11', borderRadius: 12, padding: 16, cursor: 'pointer', height: '100%' }}>
                  <h3 style={{ fontFamily: 'Syne, sans-serif', fontWeight: 600, fontSize: 14, color: '#22c55e', margin: '0 0 6px' }}>{tool.name}</h3>
                  <p style={{ color: '#6b8f6b', fontSize: 12, margin: 0, lineHeight: 1.5 }}>{tool.desc}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}

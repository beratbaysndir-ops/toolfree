'use client'
import { useState } from 'react'
export default function ContactPage() {
  const [sent, setSent] = useState(false)
  return (
    <div style={{ maxWidth: 600, margin: '0 auto', padding: '60px 16px' }}>
      <h1 style={{ fontFamily: 'Syne, sans-serif', fontSize: 36, fontWeight: 800, marginBottom: 8 }}>Contact Us</h1>
      <p style={{ color: '#6b8f6b', marginBottom: 40 }}>Have a question or suggestion? We'd love to hear from you.</p>
      {sent ? (
        <div style={{ background: '#22c55e15', border: '1px solid #22c55e40', borderRadius: 16, padding: 32, textAlign: 'center' }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>✅</div>
          <h2 style={{ fontFamily: 'Syne, sans-serif', color: '#22c55e', marginBottom: 8 }}>Message Sent!</h2>
          <p style={{ color: '#6b8f6b' }}>Thanks for reaching out. We'll get back to you within 24-48 hours.</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div><label style={{ fontSize: 13, color: '#6b8f6b', display: 'block', marginBottom: 8 }}>Your Name</label><input className="tool-input" placeholder="John Doe" /></div>
          <div><label style={{ fontSize: 13, color: '#6b8f6b', display: 'block', marginBottom: 8 }}>Email Address</label><input className="tool-input" type="email" placeholder="john@example.com" /></div>
          <div><label style={{ fontSize: 13, color: '#6b8f6b', display: 'block', marginBottom: 8 }}>Subject</label>
            <select className="tool-input">
              <option>General Question</option>
              <option>Bug Report</option>
              <option>Feature Request</option>
              <option>Business Inquiry</option>
            </select>
          </div>
          <div><label style={{ fontSize: 13, color: '#6b8f6b', display: 'block', marginBottom: 8 }}>Message</label><textarea className="tool-input" placeholder="Your message here..." style={{ minHeight: 150 }} /></div>
          <button className="btn-primary" style={{ fontSize: 16, padding: '14px' }} onClick={() => setSent(true)}>Send Message</button>
        </div>
      )}
    </div>
  )
}
